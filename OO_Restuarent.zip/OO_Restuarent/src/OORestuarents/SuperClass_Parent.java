/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package OORestuarents;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

/**
 *
 * @author user
 */
public class SuperClass_Parent {
    
    //Meals Variables
    public double FiletOFish;
    public double ChickenBurger;
    public double ChickenLegend;
    public double ChickenBurgerMeal;
    public double BaconCheeseBurger;
    
    //Drinks Variables
    
    public double MilkShake;
    public double VanillaCone;
    public double ClassicVanilla;
    public double VanillaMilkShake;
    public double ChocolateMilkShake;
    
    public double Meals;
    public double Drinks;
    public double TotalofMD;
    
    public double AllTotalCost;
    
    public double GetAmount(){
        
        Meals = FiletOFish + ChickenBurger + ChickenLegend + ChickenBurgerMeal + BaconCheeseBurger; //Add all the meals together
        Drinks = MilkShake + VanillaCone + ClassicVanilla + VanillaMilkShake + ChocolateMilkShake; //Addd all the drinks together
        
        TotalofMD = Meals + Drinks;
        
        AllTotalCost = TotalofMD;
        
        return AllTotalCost;
    }
    
    private JFrame frame;
    
    public void iExistSystem(){
        frame = new JFrame("Exit");
        
        if(JOptionPane.showConfirmDialog(frame, "Confirm if you want to exit","Restaurent Management Systems", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION){
            System.exit(0);
        };
        
    }
    
    //==========Prices=============//
    
        //Prices of Meals 
       public double pFiletOFish = 3.56;
       public double pChickenBurger = 2.95;
       public double pChickenLegend = 3.98;
       public double pChickenBurgerMeal = 2.65;
       public double pBaconCheeseBurger = 3.64;

       //Proces of Drinks

       public double pMilkShake = 2.10;
       public double pVanillaCone = 2.20;
       public double pClassicVanilla = 2.50;
       public double pVanillaMilkShake = 1.95;
       public double pChocolateMilkShake = 2.37;
       
    //================================//
       
       
    //Calculate the Tax Amount   
     public double mcTax = 0.90;
     
     public Double cFindTax(double cAmount){
         
         double FindTax = cAmount - (cAmount * mcTax);
         
         return FindTax;
    }
       
  
}
